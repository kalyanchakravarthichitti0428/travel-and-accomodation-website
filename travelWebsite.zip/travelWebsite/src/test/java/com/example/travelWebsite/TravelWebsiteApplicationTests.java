package com.example.travelWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
