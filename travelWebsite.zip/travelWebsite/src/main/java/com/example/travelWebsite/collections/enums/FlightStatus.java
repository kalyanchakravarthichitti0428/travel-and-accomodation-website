package com.example.travelWebsite.collections.enums;

public enum FlightStatus {
    DEPARTED,
    ARRIVAL,
    IN_TRANSIT;
}
