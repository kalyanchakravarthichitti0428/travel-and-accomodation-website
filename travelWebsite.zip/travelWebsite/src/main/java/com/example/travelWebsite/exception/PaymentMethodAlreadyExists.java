package com.example.travelWebsite.exception;

public class PaymentMethodAlreadyExists extends Exception{
    public PaymentMethodAlreadyExists(String msg){
        super(msg);
    }
}
