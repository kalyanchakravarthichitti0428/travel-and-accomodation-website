package com.example.travelWebsite.collections.enums;

public enum FlightType {
    INTERNATIONAL,
    DOMESTIC;
}
