package com.example.travelWebsite.exception;

public class UserDoesNotExist extends Exception{
    public UserDoesNotExist(String msg){
        super(msg);
    }
}
